from django.shortcuts import render
from django.http import HttpResponse, HttpResponseRedirect
from .models import WoWClass, WoWSpecialization, WoWClassTip , WoWClassComment ,WoWSpecializationTip ,WoWSpecializationComment
from .forms import forms
from django.contrib import messages
def index(response):
    return HttpResponse("Vitej na me strance")


def classoverview(response, name):
    classwow = WoWClass.objects.get(name=name)
    specswow = WoWSpecialization.objects.filter(wowclass=classwow)
    return render(response, "evidence/class_desc.html", {"class": classwow, "specs": specswow})
# Create your views here.
def home (response):
    classes = WoWClass.objects.all()
    return render(response, "evidence/home.html", {"classes": classes})

def specoverview(response, name, spec):


    classwow = WoWClass.objects.get(name=name)
    specwow = WoWSpecialization.objects.get(name=spec, wowclass=classwow)
    return render(response, "evidence/spec_desc.html", {"class": classwow, "spec": specwow})

def classtip(response, name, id):
    classwow = WoWClass.objects.get(name=name)
    tip = WoWClassTip.objects.get(id=id)
    comments = WoWClassComment.objects.filter(tip=tip)
    return render(response, "evidence/class_tip.html", {"class": classwow, "id": id, "tip": tip, "comments":comments })

def classtips(response, name):
    classwow = WoWClass.objects.get(name=name)
    tips = WoWClassTip.objects.filter(wowclass=classwow)
    return render(response, "evidence/class_tips.html", {"classa": classwow, "tips": tips})

def new_class_tip(response, name):
    classwow = WoWClass.objects.get(name=name)
    if response.method == "POST":
        form = forms.CreateTip(response.POST)
        if form.is_valid():
            title = form.cleaned_data["title"]
            text = form.cleaned_data["text"]
            t = WoWClassTip(title=title, text=text, wowclass=classwow)
            messages.success(response, "Uloženo do databáze")
            t.save()
        return  HttpResponseRedirect("/class/%s/tips/" % classwow.name)
    else:
        form = forms.CreateTip()
    return render (response, "evidence/new_class_tip.html", {"form": form, "classa": classwow})

def new_class_comment(response, name, id):
    classwow = WoWClass.objects.get(name=name)
    tip = WoWClassTip.objects.get(id=id)
    if response.method == "POST":
        form = forms.CreateComment(response.POST)
        if form.is_valid():

            text = form.cleaned_data["text"]
            t = WoWClassComment(text=text, tip=tip)
            messages.success(response, "Uloženo do databáze")
            t.save()
        return HttpResponseRedirect("/class/%s/tips/%i" % (name, id))
    else:
        form = forms.CreateComment()
    return render(response, "evidence/new_class_comment.html", {"form": form, "classa": classwow, "id":id})


def spectips(response, name, spec):
    specs = WoWSpecialization.objects.get(name=spec)
    tips = WoWSpecializationTip.objects.filter(spec=specs.id)
    classwow = WoWClass.objects.get(name=name)
    return render(response, "evidence/spec_tips.html", {"classa": classwow, "tips": tips, "spec": specs})

def spectip(response, name,spec, id):
    classwow = WoWClass.objects.get(name=name)
    specs = WoWSpecialization.objects.get(name=spec)
    tip = WoWSpecializationTip.objects.get(id=id)
    comments = WoWSpecializationComment.objects.filter(tip=tip)

    return render(response, "evidence/spec_tip.html", {"class": classwow, "id": id, "tip": tip, "comments":comments, "spec":specs })

def new_spec_tip(response, name, spec):
    classwow = WoWClass.objects.get(name=name)
    specs = WoWSpecialization.objects.get(name=spec)
    if response.method == "POST":
        form = forms.CreateTip(response.POST)
        if form.is_valid():
            title = form.cleaned_data["title"]
            text = form.cleaned_data["text"]
            t = WoWSpecializationTip(title=title, text=text, spec=specs)
            messages.success(response, "Uloženo do databáze")
            t.save()

        return  HttpResponseRedirect("/class/"+name+"/"+spec+"/tips/" )
    else:
        form = forms.CreateTip()
    return render (response, "evidence/new_spec_tip.html", {"form": form, "classa": classwow, "spec": specs})

def new_spec_comment(response, name, spec, id):
    classwow = WoWClass.objects.get(name=name)
    specs = WoWSpecialization.objects.get(name=spec)
    tip = WoWSpecializationTip.objects.get(id=id)
    if response.method == "POST":
        form = forms.CreateComment(response.POST)
        if form.is_valid():

            text = form.cleaned_data["text"]
            t = WoWSpecializationComment(text=text, tip=tip)
            messages.success(response, "Uloženo do databáze")
            t.save()

        return HttpResponseRedirect("/class/%s/%s/tips/%i" % (name,spec, id))
    else:
        form = forms.CreateComment()
    return render(response, "evidence/new_spec_comment.html", {"form": form, "classa": classwow, "spec":specs ,"id":id})
