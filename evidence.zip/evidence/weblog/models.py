from django.db import models
from embed_video.fields import EmbedVideoField
class WoWClass (models.Model):

    name = models.CharField(max_length = 30)
    class_img_url = models.CharField(max_length = 300)
    video_url = EmbedVideoField(default='https://www.youtube.com/watch?v=dQw4w9WgXcQ')
    icon_url = models.CharField(max_length = 300, default='https://wow.zamimg.com/images/wow/icons/medium/classicon_warrior.jpg')
    desc = models.TextField()
    def __str__(self):
        return ("{}".format(self.name))

class WoWSpecialization(models.Model):
    wowclass = models.ForeignKey('WoWClass', on_delete = models.CASCADE)
    atributes = [
        ("Intelligence", "Intelligence"),
        ("Agility", "Agility"),
        ("Strength", "Strength")
    ]
    roles = [
        ("Damage", "Damage"),
        ("Healer", "Healer"),
        ("Tank", "Tank")
    ]
    primary_atribute = models.CharField(max_length=30, choices=atributes)
    role = models.CharField(max_length=30, choices=roles, default="Damage")
    spec_img_url = models.CharField(max_length=300)
    name = models.CharField(max_length=30)
    desc = models.TextField()
    video_url = EmbedVideoField( default="https://www.youtube.com/watch?v=dQw4w9WgXcQ")
    def __str__(self):
        return ("{}".format(self.name))

class WoWClassTip(models.Model):
    title = models.CharField(max_length = 45)
    text = models.TextField(help_text='Type you tip here')
    wowclass = models.ForeignKey('WoWClass', on_delete = models.CASCADE)
    likes = models.IntegerField(default=0)
    def __str__(self):
        return ("{}".format(self.title))
class WoWSpecializationTip(models.Model):
    title = models.CharField(max_length = 45)
    text = models.TextField(help_text='Type you tip here')
    spec = models.ForeignKey('WoWSpecialization', on_delete = models.CASCADE)
    likes = models.IntegerField(default=0)
    def __str__(self):
        return ("{}".format(self.title))

class WoWClassComment(models.Model):
    text = models.TextField()
    tip = models.ForeignKey('WoWClassTip', on_delete = models.CASCADE)
    def __str__(self):
        return self.tip.wowclass.name  + ' tip id ' + str(self.tip.id) + ' comment id ' + str(self.id)
class WoWSpecializationComment(models.Model):
    text = models.TextField()
    tip = models.ForeignKey('WoWSpecializationTip', on_delete = models.CASCADE)


# Create your models here.
