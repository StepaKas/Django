from django.urls import path

from . import  views

urlpatterns = [
    path("", views.home, name="home"),
    path("class/<str:name>/", views.classoverview, name="classoverview"),
    path("class/<str:name>/<str:spec>", views.specoverview, name="specoverview"),
    path("class/<str:name>/tips/<int:id>/", views.classtip, name="classtip"),
    path("class/<str:name>/tips/", views.classtips, name="classtips"),
    path("class/<str:name>/tips/create/", views.new_class_tip , name="new_class_tip"),
    path("class/<str:name>/tips/<int:id>/create/", views.new_class_comment , name="new_class_comment"),
    path("class/<str:name>/<str:spec>/tips/", views.spectips, name="spectips"),
    path("class/<str:name>/<str:spec>/tips/<int:id>/", views.spectip, name="spectip"),
    path("class/<str:name>/<str:spec>/tips/create/", views.new_spec_tip, name="new_spec_tip"),
    path("class/<str:name>/<str:spec>/tips/<int:id>/create/", views.new_spec_comment , name="new_spec_comment"),
]