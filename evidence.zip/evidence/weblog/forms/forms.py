from django import  forms

class CreateTip(forms.Form):
    title = forms.CharField(label="Title", max_length=45)
    text = forms.CharField(widget=forms.Textarea)

class CreateComment(forms.Form):

    text = forms.CharField(widget=forms.Textarea)
