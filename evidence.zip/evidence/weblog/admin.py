from django.contrib import admin

from .models import WoWSpecializationComment, WoWSpecializationTip, WoWSpecialization, WoWClassComment ,WoWClass ,WoWClassTip
# Register your models here.
admin.site.register(WoWSpecializationComment)
admin.site.register(WoWSpecializationTip)
admin.site.register(WoWSpecialization)
admin.site.register(WoWClassComment)
admin.site.register(WoWClass)
admin.site.register(WoWClassTip)